let imgBx = document.querySelectorAll(".imgBx");
let close = document.querySelectorAll(".closebtn");
let tog = false;
imgBx.forEach(popup => popup.addEventListener('click', () => {
    if ( tog === true ) {
    popup.classList.remove("active-pop")
    } else {
        popup.classList.add("active-pop")
    }
    tog = false
}))

close.forEach(close => close.addEventListener('click', () => {
    tog = true
}))
